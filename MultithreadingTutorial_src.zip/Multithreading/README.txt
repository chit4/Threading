Rex Jaeschke wrote a 2 part series of articles concerning Multithreading
in managed C++.  His article entitled "C++/CLI Threading: Part 1"
appeared in the Oct 2005 issue of the C/C++ Users Journal and his
article entitled "C++/CLI Threading: Part II" appeared in the
Nov 2005 issue.  I decided to port as much of this code as possible
to straight C++.

Jaeschke's code (just listing files, no workspaces) can be downloaded
from:
    http://www.ddj.com/code/

The original magazine articles are also still available at:
  Part 1: http://www.ddj.com/dept/windows/184402018 
  Part 2: http://www.ddj.com/dept/windows/184402029 

John Kopplin
